'use strict';
(() => {
  const { h, api, setCsrf, rupees, fmtDate, toast } = window.TW;
  const $ = (s) => document.querySelector(s);
  let status = 'pending';

  async function init() {
    try {
      const { user, csrf } = await api('/api/me');
      if (user.role !== 'admin') throw Object.assign(new Error('Your account is not an admin.'), { status: 403 });
      setCsrf(csrf);
      $('#admin').hidden = false;
      loadAll();
    } catch (err) {
      if (err.status === 403) $('#denied-msg').textContent = err.message;
      $('#admin').hidden = true;
      $('#denied').hidden = false;
    }
  }

  const loadAll = () => Promise.all([loadStats(), loadPayouts(), loadInquiries()]).catch((err) => toast(err.message));

  async function loadStats() {
    const s = await api('/api/admin/stats');
    const card = (tag, value) => h('div', { class: 'card' }, h('span', { class: 'tag' }, tag), h('div', { class: 'big' }, value));
    $('#stats').replaceChildren(
      card('USERS', s.users),
      card('TASKS ACCEPTED TODAY', s.tasksToday),
      card(`PENDING (${s.pending.c})`, '₹' + rupees(s.pending.s)),
      card('TOTAL PAID', '₹' + rupees(s.paid)));
  }

  async function act(id, action) {
    let note = null;
    if (action === 'reject') {
      note = prompt('Reason for rejection (shown to the user):', 'Suspicious activity');
      if (note === null) return;
    } else if (!confirm('Confirm you have already sent this money via UPI?')) return;
    try {
      await api(`/api/admin/payouts/${id}`, { method: 'POST', body: { action, note } });
      toast(action === 'paid' ? 'Marked as paid' : 'Rejected and refunded to balance');
      loadAll();
    } catch (err) { toast(err.message); }
  }

  async function block(userId, blocked) {
    if (!confirm(blocked ? 'Block this user and sign them out?' : 'Unblock this user?')) return;
    try {
      await api(`/api/admin/users/${userId}/block`, { method: 'POST', body: { blocked } });
      toast(blocked ? 'User blocked' : 'User unblocked');
      loadPayouts();
    } catch (err) { toast(err.message); }
  }

  async function loadPayouts() {
    const { items } = await api('/api/admin/payouts?status=' + encodeURIComponent(status));
    $('#payout-rows').replaceChildren(...(items.length ? items.map((p) => h('tr', {},
      h('td', {}, p.id),
      h('td', {}, fmtDate(p.createdAt)),
      h('td', {}, h('div', {}, p.name), h('div', { class: 'fine' }, p.email)),
      h('td', {}, '₹' + rupees(p.amount)),
      h('td', { class: 'mono' }, p.upiId),
      h('td', {}, `${p.accepted} / ${p.rejected}`),
      h('td', {}, h('div', { class: 'row-actions no-m' },
        p.status === 'pending' && h('button', { class: 'btn btn-sm btn-primary', type: 'button', onclick: () => act(p.id, 'paid') }, 'Mark paid'),
        p.status === 'pending' && h('button', { class: 'btn btn-sm btn-danger', type: 'button', onclick: () => act(p.id, 'reject') }, 'Reject'),
        h('button', { class: 'btn btn-sm', type: 'button', onclick: () => block(p.userId, !p.blocked) }, p.blocked ? 'Unblock' : 'Block user'),
        p.note && h('span', { class: 'fine' }, p.note)))))
      : [h('tr', {}, h('td', { colspan: 7, class: 'muted' }, 'Nothing here.'))]));
  }

  async function loadInquiries() {
    const { items } = await api('/api/admin/inquiries');
    $('#inquiry-rows').replaceChildren(...(items.length ? items.map((q) => h('tr', {},
      h('td', {}, fmtDate(q.createdAt)), h('td', {}, q.company), h('td', {}, q.email), h('td', {}, q.message)))
      : [h('tr', {}, h('td', { colspan: 4, class: 'muted' }, 'No inquiries yet.'))]));
  }

  document.querySelectorAll('[data-status]').forEach((btn) => btn.addEventListener('click', () => {
    status = btn.dataset.status;
    document.querySelectorAll('[data-status]').forEach((b) => b.classList.toggle('active', b === btn));
    loadPayouts().catch((err) => toast(err.message));
  }));

  init();
})();
