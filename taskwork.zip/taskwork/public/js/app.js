'use strict';
(() => {
  const { h, api, setCsrf, rupees, fmtDate, toast } = window.TW;
  const $ = (s) => document.querySelector(s);
  let me = null;
  let minPayout = 30000;
  let current = null;
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

  const show = (id) => ['loading', 'auth', 'dash'].forEach((x) => { $('#' + x).hidden = x !== id; });
  const buddy = (text, mood) => window.TW_BUDDY && window.TW_BUDDY.say(text, mood);
  const calm = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function confetti(originEl) {
    if (calm) return;
    const r = originEl.getBoundingClientRect();
    const colors = ['#ff6b4a', '#ffc93c', '#2f9e6e', '#8ecae6', '#cdb4db'];
    const x0 = r.left + r.width / 2;
    const y0 = r.top + 10;
    for (let i = 0; i < 30; i++) {
      const c = document.createElement('span');
      c.className = 'confetti';
      c.style.setProperty('--x0', x0 + 'px');
      c.style.setProperty('--y0', y0 + 'px');
      c.style.setProperty('--x1', x0 + (Math.random() - 0.5) * 420 + 'px');
      c.style.setProperty('--y1', y0 + Math.random() * 260 - 140 + 'px');
      c.style.setProperty('--rot', Math.round(Math.random() * 720 - 360) + 'deg');
      c.style.background = colors[i % colors.length];
      c.addEventListener('animationend', () => c.remove());
      document.body.append(c);
    }
  }

  async function init() {
    try {
      const data = await api('/api/me');
      me = data.user;
      minPayout = data.minPayout;
      setCsrf(data.csrf);
      showDash();
    } catch {
      setCsrf(null);
      $('#logout-btn').hidden = true;
      $('#admin-link').hidden = true;
      show('auth');
    }
  }

  // ---- Auth ----
  document.querySelectorAll('[data-auth]').forEach((btn) => btn.addEventListener('click', () => {
    document.querySelectorAll('[data-auth]').forEach((b) => b.classList.toggle('active', b === btn));
    $('#login-form').hidden = btn.dataset.auth !== 'login';
    $('#signup-form').hidden = btn.dataset.auth !== 'signup';
    $('#auth-msg').textContent = '';
  }));

  async function authSubmit(e, path) {
    e.preventDefault();
    const form = e.currentTarget;
    const btn = form.querySelector('button[type=submit]');
    btn.disabled = true;
    $('#auth-msg').textContent = '';
    try {
      await api(path, { method: 'POST', body: Object.fromEntries(new FormData(form)) });
      form.reset();
      await init();
    } catch (err) {
      $('#auth-msg').textContent = err.message;
      buddy('Oops! ' + err.message, 'sad');
    } finally {
      btn.disabled = false;
    }
  }
  $('#login-form').addEventListener('submit', (e) => authSubmit(e, '/api/login'));
  $('#signup-form').addEventListener('submit', (e) => authSubmit(e, '/api/signup'));

  $('#logout-btn').addEventListener('click', async () => {
    try { await api('/api/logout', { method: 'POST' }); } catch { /* session already gone */ }
    me = null;
    init();
  });

  // ---- Dashboard ----
  function setBalance(paise) {
    const grew = me.balance != null && paise > me.balance;
    me.balance = paise;
    $('#balance').textContent = rupees(paise);
    if (grew) {
      const chip = $('#wallet-chip');
      chip.classList.remove('bump');
      void chip.offsetWidth;
      chip.classList.add('bump');
    }
  }

  function showDash() {
    show('dash');
    $('#logout-btn').hidden = false;
    $('#admin-link').hidden = me.role !== 'admin';
    $('#user-name').textContent = me.name;
    setBalance(me.balance);
    switchTab('tasks');
    const first = me.name.split(' ')[0];
    buddy(me.balance ? `Hey ${first}! Ready for a few more?` : `Hey ${first}! Try a captcha first — it's the easiest.`, 'wave');
  }

  document.querySelectorAll('[data-tab]').forEach((btn) => btn.addEventListener('click', () => switchTab(btn.dataset.tab)));
  function switchTab(name) {
    document.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('active', b.dataset.tab === name));
    ['tasks', 'wallet', 'history'].forEach((t) => { $('#tab-' + t).hidden = t !== name; });
    ({ tasks: loadTasks, wallet: loadWallet, history: loadHistory })[name]();
  }

  const handleAuthError = (err) => {
    if (err.status === 401) return init();
    toast(err.message);
  };

  // ---- Tasks ----
  async function loadTasks() {
    try {
      const { types, dailyLimit } = await api('/api/tasks');
      $('#task-grid').replaceChildren(...types.map((t) => {
        const pct = Math.min(100, (t.doneToday / dailyLimit) * 100);
        const bar = h('span');
        bar.style.width = pct + '%';
        return h('article', { class: 'card task-card' },
          h('span', { class: 'tag' }, '₹' + rupees(t.reward) + ' / task'),
          h('h3', {}, t.name),
          h('p', {}, `Accuracy needed: ${t.minAccuracy}%`),
          h('div', { class: 'fine' }, `Today: ${t.doneToday} / ${dailyLimit}`),
          h('div', { class: 'progress' }, bar),
          h('button', { class: 'btn btn-primary btn-sm', type: 'button', disabled: t.doneToday >= dailyLimit, onclick: () => startTask(t.type) }, 'Start'));
      }));
    } catch (err) { handleAuthError(err); }
  }

  const blockCopyPaste = (el) => {
    ['paste', 'drop'].forEach((ev) => el.addEventListener(ev, (e) => e.preventDefault()));
    el.setAttribute('autocomplete', 'off');
    el.setAttribute('spellcheck', 'false');
    return el;
  };

  function sampleBlock(display) {
    const stop = (e) => e.preventDefault();
    let el;
    if (display.kind === 'captcha') {
      if (!/^data:image\/svg\+xml;base64,[A-Za-z0-9+/=]+$/.test(display.image)) throw new Error('Invalid captcha');
      el = h('img', { class: 'captcha-img', src: display.image, alt: 'Captcha — type the characters you see', draggable: 'false' });
    } else if (display.kind === 'text') {
      el = h('div', { class: 'text-sample' }, display.text);
    } else {
      el = h('div', { class: 'record' + (display.kind === 'document' ? ' doc' : '') },
        h('h4', {}, display.title),
        h('dl', { class: 'no-m' }, display.rows.map(([k, v]) => h('div', {}, h('dt', {}, k), h('dd', { class: 'no-m' }, v)))));
    }
    ['copy', 'cut', 'contextmenu', 'dragstart'].forEach((ev) => el.addEventListener(ev, stop));
    return el;
  }

  async function startTask(type) {
    const panel = $('#task-panel');
    try {
      current = await api('/api/tasks/start', { method: 'POST', body: { type } });
    } catch (err) { return handleAuthError(err); }

    let inputs;
    let answerArea;
    if (current.fields) {
      inputs = current.fields.map((label, i) => blockCopyPaste(h('input', { id: 'f' + i, maxlength: 200 })));
      answerArea = h('div', { class: 'fields-grid' }, current.fields.map((label, i) => h('div', { class: 'field' }, h('label', { for: 'f' + i }, label), inputs[i])));
    } else if (current.display.kind === 'captcha') {
      inputs = [blockCopyPaste(h('input', { id: 'ans', maxlength: 20, autocapitalize: 'off', 'aria-label': 'Captcha answer' }))];
      answerArea = inputs[0];
    } else {
      inputs = [blockCopyPaste(h('textarea', { id: 'ans', maxlength: 2000, 'aria-label': 'Type the text above' }))];
      answerArea = inputs[0];
    }

    const result = h('div', { role: 'status' });
    const submitBtn = h('button', { class: 'btn btn-primary', type: 'submit' }, 'Submit');
    const form = h('form', { novalidate: true }, answerArea,
      h('div', { class: 'row-actions' }, submitBtn,
        h('button', { class: 'btn', type: 'button', onclick: () => startTask(type) }, 'Skip'),
        h('button', { class: 'btn btn-ghost', type: 'button', onclick: () => { panel.hidden = true; current = null; } }, 'Close')),
      result);

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!current) return;
      submitBtn.disabled = true;
      const answer = current.fields ? inputs.map((i) => i.value) : inputs[0].value;
      try {
        const r = await api(`/api/tasks/${current.id}/submit`, { method: 'POST', body: { answer } });
        setBalance(r.balance);
        const ok = r.status === 'accepted';
        if (ok) {
          buddy(pick(['Yesss! +₹' + rupees(r.reward), 'Nailed it! +₹' + rupees(r.reward), 'Clean typing! +₹' + rupees(r.reward)]), 'cheer');
          confetti(submitBtn);
        } else {
          buddy(r.accuracy >= 90 ? 'So close! Check the small stuff — dots and capitals.' : 'No worries, try the next one slowly.', 'sad');
        }
        result.replaceChildren(h('div', { class: 'result ' + (ok ? 'ok' : 'bad') },
          ok ? `Accepted! Accuracy ${r.accuracy}% · +₹${rupees(r.reward)}` : `Rejected. ${r.reason}`,
          h('div', { class: 'row-actions' }, h('button', { class: 'btn btn-sm btn-primary', type: 'button', onclick: () => startTask(type) }, 'Next task →'))));
        current = null;
        loadTasks();
      } catch (err) {
        submitBtn.disabled = false;
        handleAuthError(err);
      }
    });

    panel.replaceChildren(
      h('div', { class: 'panel-head' }, h('h3', { class: 'no-m' }, current.name),
        h('span', { class: 'pill' }, `₹${rupees(current.reward)} · needs ${current.minAccuracy}%`)),
      sampleBlock(current.display),
      form);
    panel.hidden = false;
    buddy(current.fields ? 'Go field by field. Spellings matter!' : current.display.kind === 'captcha' ? 'Squint a little… capitals count!' : 'Take it slow — accuracy beats speed.', 'type');
    panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    inputs[0].focus({ preventScroll: true });
  }

  // ---- Wallet ----
  async function loadWallet() {
    try {
      const w = await api('/api/payouts');
      setBalance(w.balance);
      $('#w-balance').textContent = rupees(w.balance);
      $('#w-progress').style.width = Math.min(100, (w.balance / w.minPayout) * 100) + '%';
      const left = w.minPayout - w.balance;
      $('#w-hint').textContent = left > 0 ? `₹${rupees(left)} more to reach the ₹${rupees(w.minPayout)} minimum payout.` : 'You can request a payout now.';
      if (w.upiId && !$('#upi').value) $('#upi').value = w.upiId;
      const pending = w.items.some((p) => p.status === 'pending');
      $('#payout-btn').disabled = left > 0 || pending;
      if (pending) $('#w-hint').textContent = 'A payout request is under review.';
      buddy(pending ? 'Your payout is with our team. Hang tight!' : left > 0 ? `Only ₹${rupees(left)} to go. You've got this!` : 'Woohoo! You can cash out now.', pending || left > 0 ? 'idle' : 'cheer');
      $('#payout-rows').replaceChildren(...(w.items.length ? w.items.map((p) => h('tr', {},
        h('td', {}, p.id), h('td', {}, fmtDate(p.createdAt)), h('td', {}, '₹' + rupees(p.amount)), h('td', {}, p.upiId),
        h('td', {}, h('span', { class: 'status ' + p.status }, p.status)), h('td', {}, p.note || '—')))
        : [h('tr', {}, h('td', { colspan: 6, class: 'muted' }, 'No payout requests yet.'))]));
    } catch (err) { handleAuthError(err); }
  }

  $('#payout-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const msg = $('#payout-msg');
    msg.className = 'form-msg';
    try {
      const r = await api('/api/payouts', { method: 'POST', body: { upiId: $('#upi').value } });
      msg.className = 'form-msg ok';
      msg.textContent = `Payout of ₹${rupees(r.amount)} requested. It is now under review.`;
      confetti($('#payout-btn'));
      loadWallet();
    } catch (err) {
      msg.className = 'form-msg err';
      msg.textContent = err.message;
      if (err.status === 401) init();
    }
  });

  // ---- History ----
  async function loadHistory() {
    try {
      const { items } = await api('/api/history');
      $('#history-rows').replaceChildren(...(items.length ? items.map((t) => h('tr', {},
        h('td', {}, t.name), h('td', {}, fmtDate(t.submittedAt)), h('td', {}, t.accuracy + '%'),
        h('td', {}, '₹' + rupees(t.reward)), h('td', {}, h('span', { class: 'status ' + t.status }, t.status))))
        : [h('tr', {}, h('td', { colspan: 5, class: 'muted' }, 'No tasks yet. Pick one from the Tasks tab.'))]));
    } catch (err) { handleAuthError(err); }
  }

  init();
})();
