'use strict';
(() => {
  document.getElementById('year').textContent = new Date().getFullYear();
  const calm = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const reveals = document.querySelectorAll('.reveal');
  if (calm || !('IntersectionObserver' in window)) reveals.forEach((el) => el.classList.add('in'));
  else {
    const io = new IntersectionObserver((entries) => entries.forEach((e) => {
      if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
    }), { threshold: 0.15 });
    reveals.forEach((el) => io.observe(el));
  }

  const typed = document.getElementById('typed');
  const words = ['captchas.', 'invoices.', 'forms.', 'whole pages.', 'courier slips.'];
  if (typed && !calm) {
    let w = 0, i = words[0].length, deleting = true;
    const tick = () => {
      const word = words[w];
      i += deleting ? -1 : 1;
      typed.textContent = word.slice(0, i) || '\u00a0';
      let delay = deleting ? 45 : 95 + Math.random() * 80;
      if (!deleting && i === word.length) { deleting = true; delay = 1800; }
      else if (deleting && i === 0) { deleting = false; w = (w + 1) % words.length; delay = 300; }
      setTimeout(tick, delay);
    };
    setTimeout(tick, 2200);
  }

  // Tappu in the hero reacts when you hover the main button.
  const cta = document.querySelector('.hero .btn-primary');
  const heroBuddy = document.querySelector('.scene .mascot');
  if (cta && heroBuddy && window.TW_BUDDY) {
    cta.addEventListener('mouseenter', () => { heroBuddy.innerHTML = window.TW_BUDDY.svg('cheer'); });
    cta.addEventListener('mouseleave', () => { heroBuddy.innerHTML = window.TW_BUDDY.svg('wave'); });
  }

  const form = document.getElementById('inquiry-form');
  const msg = document.getElementById('iq-msg');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(form));
    msg.className = 'form-msg';
    msg.textContent = 'Sending…';
    try {
      const res = await fetch('/api/inquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Could not send. Try again later.');
      form.reset();
      msg.className = 'form-msg ok';
      msg.textContent = 'Thanks! We will reply within 1 business day.';
    } catch (err) {
      msg.className = 'form-msg err';
      msg.textContent = location.protocol === 'file:' ? 'Start the server (npm start) to send inquiries.' : err.message;
    }
  });
})();
