'use strict';
// "Tappu" the keycap mascot. Static markup only — no user data is ever inserted here.
(() => {
  const INK = '#2b2118';
  const S = `stroke="${INK}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"`;

  const ARMS = {
    idle: `<g class="t-arm-l"><path d="M30 90 q-16 10 -16 28" fill="none" ${S}/><circle cx="14" cy="121" r="6" fill="#ffc93c" ${S}/></g>
           <g class="t-arm-r"><path d="M130 90 q16 10 16 28" fill="none" ${S}/><circle cx="146" cy="121" r="6" fill="#ffc93c" ${S}/></g>`,
    wave: `<g class="t-arm-l"><path d="M30 90 q-16 10 -16 28" fill="none" ${S}/><circle cx="14" cy="121" r="6" fill="#ffc93c" ${S}/></g>
           <g class="t-arm-r"><path d="M130 86 q20 -6 22 -30" fill="none" ${S}/><circle cx="152" cy="52" r="6" fill="#ffc93c" ${S}/></g>`,
    cheer: `<g class="t-arm-l"><path d="M30 86 q-20 -6 -22 -30" fill="none" ${S}/><circle cx="8" cy="52" r="6" fill="#ffc93c" ${S}/></g>
            <g class="t-arm-r"><path d="M130 86 q20 -6 22 -30" fill="none" ${S}/><circle cx="152" cy="52" r="6" fill="#ffc93c" ${S}/></g>`,
    type: `<rect x="56" y="112" width="48" height="30" rx="6" fill="${INK}" class="t-phone"/>
           <rect x="61" y="116" width="38" height="20" rx="3" fill="#8ecae6"/>
           <path class="t-screen" d="M66 122 h22 M66 128 h14" stroke="#fff" stroke-width="3" stroke-linecap="round"/>
           <g class="t-arm-l"><path d="M32 94 q8 26 30 30" fill="none" ${S}/><circle cx="64" cy="124" r="6" fill="#ffc93c" ${S}/></g>
           <g class="t-arm-r"><path d="M128 94 q-8 26 -30 30" fill="none" ${S}/><circle cx="96" cy="124" r="6" fill="#ffc93c" ${S}/></g>`,
  };

  const EYES = {
    open: `<g class="t-eyes"><ellipse cx="64" cy="70" rx="6.5" ry="8.5" fill="${INK}"/><ellipse cx="96" cy="70" rx="6.5" ry="8.5" fill="${INK}"/>
           <circle cx="66.5" cy="66.5" r="2.4" fill="#fff"/><circle cx="98.5" cy="66.5" r="2.4" fill="#fff"/></g>`,
    happy: `<path d="M57 72 q7 -10 14 0 M89 72 q7 -10 14 0" fill="none" ${S}/>`,
    closed: `<path d="M57 70 q7 6 14 0 M89 70 q7 6 14 0" fill="none" ${S}/>`,
    sad: `<g class="t-eyes"><ellipse cx="64" cy="72" rx="6" ry="7" fill="${INK}"/><ellipse cx="96" cy="72" rx="6" ry="7" fill="${INK}"/></g>
          <path d="M55 58 l14 5 M105 58 l-14 5" fill="none" ${S}/>`,
  };

  const MOUTH = {
    smile: `<path d="M70 88 q10 11 20 0" fill="none" ${S}/>`,
    open: `<path d="M68 86 q12 18 24 0 z" fill="#c1121f" ${S}/>`,
    flat: `<path d="M71 92 q9 -6 18 0" fill="none" ${S}/>`,
    o: `<ellipse cx="80" cy="91" rx="5" ry="4" fill="${INK}"/>`,
  };

  const MOODS = {
    wave: ['wave', 'open', 'smile'],
    idle: ['idle', 'open', 'smile'],
    type: ['type', 'open', 'o'],
    cheer: ['cheer', 'happy', 'open'],
    sad: ['idle', 'sad', 'flat'],
    sleep: ['idle', 'closed', 'flat'],
  };

  function svg(mood = 'wave') {
    const [arms, eyes, mouth] = MOODS[mood] || MOODS.wave;
    return `<svg viewBox="0 0 160 190" class="tappu tappu--${mood}" aria-hidden="true" focusable="false">
      <ellipse class="t-shadow" cx="80" cy="180" rx="40" ry="6" fill="${INK}" opacity=".14"/>
      <g class="t-bob">
        <path d="M62 132 q-2 16 -5 30 M98 132 q2 16 5 30" fill="none" ${S}/>
        <ellipse cx="52" cy="164" rx="12" ry="6.5" fill="#ff6b4a" ${S}/>
        <ellipse cx="108" cy="164" rx="12" ry="6.5" fill="#ff6b4a" ${S}/>
        <path d="M30 42 q0 -15 15 -15 h70 q15 0 15 15 v78 q0 15 -15 15 h-70 q-15 0 -15 -15 z" fill="#ffc93c" ${S}/>
        <path d="M40 40 q0 -6 6 -6 h68 q6 0 6 6 v58 q0 8 -8 8 h-64 q-8 0 -8 -8 z" fill="#ffdc7a"/>
        <text x="46" y="53" font-family="Consolas,monospace" font-weight="700" font-size="13" fill="${INK}" opacity=".45">T</text>
        ${eyes}
        <ellipse cx="51" cy="86" rx="7" ry="4" fill="#ff8fa3" opacity=".75"/>
        <ellipse cx="109" cy="86" rx="7" ry="4" fill="#ff8fa3" opacity=".75"/>
        ${mouth}
        ${ARMS[arms]}
      </g>
      ${mood === 'sleep' ? `<g class="t-zzz" font-family="Segoe Print,cursive" font-weight="700" fill="${INK}"><text x="128" y="30" font-size="16">z</text><text x="140" y="16" font-size="12">z</text></g>` : ''}
      ${mood === 'cheer' ? `<g class="t-sparks" ${S} stroke-width="4"><path d="M20 20 l6 6 M140 18 l-6 6 M80 4 v8"/></g>` : ''}
    </svg>`;
  }

  function mountAll(root = document) {
    root.querySelectorAll('[data-mascot]').forEach((el) => { el.innerHTML = svg(el.dataset.mascot); });
  }

  // Updates every on-page buddy (auth card + dashboard) with a mood and speech bubble.
  function say(text, mood = 'idle') {
    document.querySelectorAll('[data-buddy]').forEach((wrap) => {
      const m = wrap.querySelector('[data-mascot]');
      const bubble = wrap.querySelector('.bubble');
      if (m) { m.dataset.mascot = mood; m.innerHTML = svg(mood); }
      if (bubble) {
        bubble.textContent = text;
        bubble.classList.remove('pop');
        void bubble.offsetWidth;
        bubble.classList.add('pop');
      }
    });
  }

  window.TW_BUDDY = { svg, say, mountAll };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => mountAll());
  else mountAll();
})();
