'use strict';
// Browser-only fake backend so preview.html works by double-clicking, without a server.
(() => {
  const KEY = 'taskwork_preview';
  const TYPES = {
    captcha: { name: 'Captcha', reward: 5, minAccuracy: 100 },
    basic: { name: 'Basic Typing', reward: 30, minAccuracy: 100 },
    data: { name: 'Data Entry', reward: 100, minAccuracy: 100 },
    form: { name: 'Form Filling', reward: 150, minAccuracy: 100 },
    page: { name: 'Page Typing', reward: 250, minAccuracy: 98 },
  };
  const SENTENCES = ['Please keep the receipt safe until the parcel is delivered.', 'The meeting has been moved to Thursday at four in the evening.', 'Fresh vegetables arrive at the market every morning by six.', 'The train to Chennai departs from platform number three.'];
  const PASSAGE = 'Digital payments have completely transformed daily transactions across India in just a few short years. Small vendors selling tea, vegetables or street food now display QR codes next to their stalls.';
  const NAMES = ['Rohit Sharma', 'Priya Iyer', 'Amit Patel', 'Sneha Reddy'];
  const CITIES = [['Mumbai', '400053'], ['Pune', '411001'], ['Delhi', '110001']];
  const CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';

  const ri = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  const norm = (s) => String(s).replace(/\s+/g, ' ').trim();
  const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch { return {}; } };
  let db = load();
  const save = () => localStorage.setItem(KEY, JSON.stringify(db));
  const fail = (status, error) => Promise.reject(Object.assign(new Error(error), { status }));

  function captcha() {
    let text = '';
    for (let i = 0; i < 6; i++) text += pick(CHARS);
    let s = '<svg xmlns="http://www.w3.org/2000/svg" width="190" height="64"><rect width="100%" height="100%" fill="#f4efe3"/>';
    for (let i = 0; i < 6; i++) s += `<line x1="${ri(0, 190)}" y1="${ri(0, 64)}" x2="${ri(0, 190)}" y2="${ri(0, 64)}" stroke="#0a7a55" opacity=".5"/>`;
    [...text].forEach((c, i) => { const x = 16 + i * 28, y = ri(38, 48); s += `<text x="${x}" y="${y}" font-family="Georgia" font-size="30" font-weight="700" fill="#1d1b16" transform="rotate(${ri(-25, 25)} ${x} ${y})">${c}</text>`; });
    return { display: { kind: 'captcha', image: 'data:image/svg+xml;base64,' + btoa(s + '</svg>') }, expected: text };
  }
  const GEN = {
    captcha,
    basic: () => { const t = pick(SENTENCES) + ' ' + pick(SENTENCES); return { display: { kind: 'text', text: t }, expected: t }; },
    page: () => ({ display: { kind: 'text', text: PASSAGE }, expected: PASSAGE }),
    data: () => {
      const [city, pin] = pick(CITIES);
      const rows = [['AWB', 'AWB' + ri(10000000, 99999999)], ['Name', pick(NAMES)], ['City', city], ['PIN', pin], ['Amount', ri(100, 9999) + '.00']];
      return { display: { kind: 'record', title: 'Courier receipt', rows }, fields: rows.map((r) => r[0]), expected: rows.map((r) => r[1]) };
    },
    form: () => {
      const name = pick(NAMES);
      const [city, pin] = pick(CITIES);
      const rows = [['Full Name', name], ['Date of Birth', `${ri(10, 28)}/0${ri(1, 9)}/${ri(1970, 2004)}`], ['City', city], ['PIN', pin], ['Mobile', '9' + ri(100000000, 999999999)], ['Email', name.toLowerCase().replace(' ', '.') + '@example.com']];
      return { display: { kind: 'document', title: 'Applicant details', rows }, fields: rows.map((r) => r[0]), expected: rows.map((r) => r[1]) };
    },
  };

  function lev(a, b) {
    let prev = Array.from({ length: b.length + 1 }, (_, j) => j);
    for (let i = 1; i <= a.length; i++) {
      const cur = [i];
      for (let j = 1; j <= b.length; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = cur;
    }
    return prev[b.length];
  }
  const accuracy = (e, t) => { const m = Math.max(e.length, t.length); return m ? Math.floor((1 - lev(e, t) / m) * 10000) / 100 : 0; };

  const routes = {
    'GET /api/me': () => (db.user ? { user: db.user, csrf: 'preview', minPayout: 30000 } : fail(401, 'Please sign in')),
    'POST /api/login': (b) => {
      if (!b.email || !b.password) return fail(401, 'Invalid email or password');
      db.user = db.user || { id: 1, name: b.email.split('@')[0], email: b.email, role: 'user', balance: 0, upiId: null };
      save();
      return { ok: true };
    },
    'POST /api/signup': (b) => {
      if (!b.name || norm(b.name).length < 2) return fail(400, 'Name must be 2-60 letters');
      if (!/^\S+@\S+\.\S+$/.test(b.email || '')) return fail(400, 'Enter a valid email address');
      if ((b.password || '').length < 8) return fail(400, 'Password must be 8-128 characters');
      db = { user: { id: 1, name: norm(b.name), email: b.email, role: 'user', balance: 0, upiId: null }, history: [], payouts: [] };
      save();
      return { ok: true };
    },
    'POST /api/logout': () => { db.user = null; save(); return { ok: true }; },
    'GET /api/tasks': () => ({
      dailyLimit: 200,
      types: Object.entries(TYPES).map(([type, t]) => ({ type, ...t, doneToday: (db.history || []).filter((x) => x.type === type && x.status === 'accepted' && new Date(x.submittedAt).toDateString() === new Date().toDateString()).length })),
    }),
    'POST /api/tasks/start': (b) => {
      const t = GEN[b.type]();
      db.task = { id: Date.now(), type: b.type, expected: t.expected, issuedAt: Date.now() };
      save();
      return { id: db.task.id, type: b.type, ...TYPES[b.type], display: t.display, fields: t.fields || null };
    },
    'POST /api/tasks/:id/submit': (b, id) => {
      const t = db.task;
      if (!t || String(t.id) !== id) return fail(409, 'This task was already submitted or has expired');
      const exp = Array.isArray(t.expected) ? t.expected.map(norm).join('\n') : norm(t.expected);
      const ans = Array.isArray(b.answer) ? b.answer.map(norm).join('\n') : norm(b.answer);
      const acc = accuracy(exp, ans);
      const meta = TYPES[t.type];
      const tooFast = Date.now() - t.issuedAt < Math.max(1500, exp.length * 1000 / 12);
      const status = !tooFast && acc >= meta.minAccuracy ? 'accepted' : 'rejected';
      const reward = status === 'accepted' ? meta.reward : 0;
      db.user.balance += reward;
      db.history = [{ id: t.id, type: t.type, name: meta.name, status, accuracy: acc, reward, submittedAt: Date.now() }, ...(db.history || [])].slice(0, 50);
      db.task = null;
      save();
      const reason = status === 'accepted' ? null : tooFast ? 'Submitted too quickly. Please type the task yourself.' : `Accuracy ${acc}% is below the required ${meta.minAccuracy}%.`;
      return { status, accuracy: acc, reward, reason, balance: db.user.balance };
    },
    'GET /api/history': () => ({ items: db.history || [] }),
    'GET /api/payouts': () => ({ balance: db.user.balance, minPayout: 30000, upiId: db.user.upiId, items: db.payouts || [] }),
    'POST /api/payouts': (b) => {
      if (!/^[a-zA-Z0-9._-]{2,64}@[a-zA-Z][a-zA-Z0-9]{1,31}$/.test((b.upiId || '').trim())) return fail(400, 'Enter a valid UPI ID, e.g. name@okaxis');
      if ((db.payouts || []).some((p) => p.status === 'pending')) return fail(409, 'You already have a payout request under review');
      if (db.user.balance < 30000) return fail(400, 'Minimum payout is ₹300');
      const p = { id: (db.payouts || []).length + 1, amount: db.user.balance, upiId: b.upiId.trim(), status: 'pending', note: 'Preview only — no money is sent', createdAt: Date.now() };
      db.payouts = [p, ...(db.payouts || [])];
      db.user.upiId = p.upiId;
      db.user.balance = 0;
      save();
      return p;
    },
  };

  window.TW_MOCK_API = async (path, { method = 'GET', body } = {}) => {
    const m = path.match(/^\/api\/tasks\/(\d+)\/submit$/);
    const handler = m ? routes['POST /api/tasks/:id/submit'] : routes[`${method} ${path}`];
    if (!handler) return fail(404, 'Not available in preview');
    if (!db.user && !['GET /api/me', 'POST /api/login', 'POST /api/signup'].includes(`${method} ${path}`)) return fail(401, 'Please sign in');
    return handler(body || {}, m && m[1]);
  };
})();
