'use strict';
const { createDb } = require('../db');
const { cleanEmail } = require('../lib/security');

const email = cleanEmail(process.argv[2]);
if (!email) {
  console.error('Usage: npm run make-admin -- user@example.com');
  process.exit(1);
}
const r = createDb().prepare(`UPDATE users SET role = 'admin' WHERE email = ?`).run(email);
console.log(r.changes ? `${email} is now an admin.` : `No user found with email ${email}. Sign up first.`);
